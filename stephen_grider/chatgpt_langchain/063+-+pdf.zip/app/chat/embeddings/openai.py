from langchain.embeddings import OpenAIEmbeddings

embeddings = OpenAIEmbeddings()