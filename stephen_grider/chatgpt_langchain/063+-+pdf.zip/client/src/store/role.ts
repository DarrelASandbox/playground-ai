export enum Role {
	User = 'user',
	Assistant = 'assistant',
	System = 'system',
	Pending = 'pending'
}
